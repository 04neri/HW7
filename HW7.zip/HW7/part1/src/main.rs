// Design a data type Shape that can be used for storing a triangle, rectangle, OR circle
enum Shapes { // i set the shapes here
    Triangle(f32, f32, f32),
    Rectangle(f32, f32),
    Circle(f32),
}

impl Shapes { // auxiliary function to create instances of the type
    // create instances of the three shapes
    fn new_triangle(a: f32, b: f32, c: f32) -> Shapes { // side a, side b, side c
        Shapes::Triangle(a, b, c)
    }
    fn new_rectangle(l: f32, w: f32) -> Shapes {
        Shapes::Rectangle(l, w) // length, width
    }
    fn new_circle(r: f32) -> Shapes {
        Shapes::Circle(r) // radius
    }
    // method that computes the area of the shape
    fn area(&self) -> f32 {
        match *self {
            Shapes::Triangle(a, b, c) => {
                let s: f32 = (a + b + c) / 2.0;
                (s * (s - a) * (s - b) * (s - c)).sqrt() // Heron’s formula
            }
            Shapes::Rectangle(l, w) => l * w, // length x width
            Shapes::Circle(r) => 3.14 * r * r  // radius x radius
        }
    }

    // method that computes the perimeter of the shape
    fn perimeter(&self) -> f32 {
        match *self {
            Shapes::Triangle(a, b, c) => a + b + c,
            Shapes::Rectangle(l, w) => 2.0 * (l + w),
            Shapes::Circle(r) => 2.0 * 3.14 * r,
        }
    }

    // method that doubles the perimeter of the shape
    fn double_perimeter(&self) -> f32 {
        2.0 * self.perimeter()
    }

    // method that verifies the correctness of the parameters of the shape
    fn is_valid(&self) -> bool {
        match *self {
            Shapes::Triangle(a, b, c) => {
                a > 0.0 && b > 0.0 && c > 0.0 && (a + b > c) && (b + c > a) && (a + c > b)
            },
            Shapes::Rectangle(l, w) => l > 0.0 && w > 0.0,
            Shapes::Circle(r) => r > 0.0,
        }
    }
}
fn main() {
    let triangle = Shapes::new_triangle(12.3, 36.9, 42.0);
    println!("TRIANGLE");
    println!("Area: {}, Perimeter: {}, Double Perimeter: {}", triangle.area(), triangle.perimeter(), triangle.double_perimeter());
    println!("Validity of Parameters: {}", triangle.is_valid());

    let rectangle = Shapes::new_rectangle(6.19, 11.0);
    println!("RECTANGLE");
    println!("Area: {}, Perimeter: {}, Double Perimeter: {}", rectangle.area(), rectangle.perimeter(), rectangle.double_perimeter());
    println!("Validity of Parameters: {}", rectangle.is_valid());

    let circle = Shapes::new_circle(4.2);
    println!("CIRCLE");
    println!("Area: {}, Perimeter: {}, Double Perimeter: {}", circle.area(), circle.perimeter(), circle.double_perimeter());
    println!("Validity of Parameters: {}", circle.is_valid());
}
