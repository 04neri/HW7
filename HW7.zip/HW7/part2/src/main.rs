use std::f64::consts::PI;

// create a struct for a canonical polygon with an arbitrary number of sides and length
struct CanonicalPolygon {
    num_of_sides: u32, // integer
    length_of_side: f64, // float
}

// create a trait for a canonical polygon
// ensure that the trait includes method prototypes for the perimeter, area and radius of this polygon
trait PolygonTrait {
    fn perimeter(&self) -> f64;
    fn area(&self) -> f64;
    fn radius(&self) -> f64;
}

// implement "PolygonTrait" methods for the "CanonicalPolygon" struct
impl PolygonTrait for CanonicalPolygon {
    fn perimeter(&self) -> f64 {
        self.num_of_sides as f64 * self.length_of_side
    }
    fn area(&self) -> f64 {
        let interior_angle = 2.0 * PI / self.num_of_sides as f64;
        0.5 * self.num_of_sides as f64 * self.length_of_side * self.length_of_side * interior_angle.sin()
    }
    fn radius(&self) -> f64 {
        0.5 * self.length_of_side / (PI / self.num_of_sides as f64).sin()
    }
}

// created my main function that works as entry point
fn main() {
    let sides = vec![6, 12, 24, 128, 256, 512, 1024, 2048, 65536];
    let lengths = vec![7.0, 15.0, 23.0];

    for &num_of_sides in &sides {
        for &length_of_side in &lengths {
            let polygon = CanonicalPolygon {num_of_sides, length_of_side};
            println!("Canonical Polygon with side length of {} and {} sides has an area of {}", length_of_side, num_of_sides,polygon.area()
            );

            // i calc the area of a circle with the same radius
            let radius = polygon.radius();
            let circle_area = PI * radius.powi(2);
            println!("Circle area w same radius is: {}", circle_area);
            println!();
        }
    }
}